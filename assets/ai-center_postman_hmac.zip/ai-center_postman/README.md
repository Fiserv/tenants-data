# Fiserv Postman Collection

This demo shows how to use the Fiserv AI Center API Keys work with Postman collections.

## Running the Postman Collection
- Create an API Key from AI Center Workspace
- Add the API key to the `AppConsumerKey` variable
- Add the API secret to the `AppConsumerSecret` variable
- Run the postman collection
