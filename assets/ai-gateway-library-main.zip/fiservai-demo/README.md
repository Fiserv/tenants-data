# FiservAI Python Package

This demo shows basic usage of the FiservAI python package, which is used to integrate with the Fiserv AI Gateway

## Installation
- Create and activate virtual environment:  `python3.10 -m venv venv; source venv/bin/activate`
  
- Run the package installation script: `pip3 --trusted-host pypi.org --trusted-host files.pythonhosted.org --trusted-host github.com --trusted-host objects.githubusercontent.com install -r requirements.txt`

## Configuration

Update the following variables in the `.ENV` file with what is provided from the Developer Studio workspace
- **API_KEY** =  API Key provided from Developer Studio
- **API_SECRET** = API Secret provided from Developer Studio
- **BASE_URL** = "https://connect-uat.fiservapis.com/ai-gateway/v1"

## Running the demo
- Run the demo: `python tiny_test.py`
- *Note: If python command does not work, please try running with `python3 tiny_test.py`*
