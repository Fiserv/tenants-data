import asyncio
import json
import os
import time

from dotenv import load_dotenv

from fiservai import FiservAI

# Load environment variables from .env file
load_dotenv()

# Read API_KEY and API_SECRET from environment variables
API_KEY = os.getenv("API_KEY")
if API_KEY is None or API_KEY == "":
    raise ValueError("API_KEY is not set. Check your environment variables or add a .env file with API_KEY and API_SECRET.")
API_SECRET = os.getenv("API_SECRET")
if API_SECRET is None or API_SECRET == "":
    raise ValueError("API_SECRET is not set. Check your environment variables or add a .env file with API_KEY and API_SECRET.")

# Utility function to print diagnostics
def print_diagnostics(resp, elapsed_time_sec):
    print(f"""[Model: {resp.model}, Prompt Tokens: {resp.usage.prompt_tokens}, Completion Tokens: {resp.usage.completion_tokens}, Total Tokens: {resp.usage.total_tokens}, Cost: ${resp.usage.cost}, Time: {elapsed_time_sec} sec]""")
    
# Create a FiservAI client
# Use this to specify a non-default model 
# client = FiservAI.FiservAI(API_KEY, API_SECRET, model_name = "azure-openai-3.5-turbo-16-east")
# Use this to use the default model
client = FiservAI.FiservAI(API_KEY, API_SECRET)

# Get list of available models
try:
    print("Getting list of supported models")
    resp = client.get_models()
    print(json.dumps(resp, indent=4))
except Exception as e:
    print(f"An exception occurred: {str(e)}")

# Demonstrate chat completion in async mode
async def main():

    try:
        print("Perform a simple completion in async mode")        
        prompt = "What is the capital of France?"
        print(f"Prompt: {prompt}")
        now = time.time()
        resp = await client.chat_completion_async(prompt)
        print(resp.choices[0].message.content)
        print_diagnostics(resp, int(time.time()-now))
        print()
    except Exception as e:
        print(f"An exception occurred: {str(e)}")

    try:
        print("Perform a conversational completion in async mode")
        messages = [
            {
                "role": "system",
                "content": "You are a pirate.  Answer all questions in pirate-speak",
            },
            {
                "role": "user",
                "content": "how big is the moon?",
            },
            {
                "role": "assistant",
                "content": "Arr, the moon be a mighty fine sight, me heartie. 'Tis 'bout 2,159 nautical miles in diameter, if ye be wantin' to know the size of that celestial beauty.",
            },
            {
                "role": "user",
                "content": "what about the sun?",
            },
            
        ]        

        prompt = "<<conversation with a pirate>>"
        print(f"Prompt: {prompt}")
        now = time.time()
        resp = await client.chat_completion_async(messages)
        print(resp.choices[0].message.content)
        print_diagnostics(resp, int(time.time()-now))
        print()

    except Exception as e:
        print(f"An exception occurred: {str(e)}")

asyncio.run(main())

# Demonstrate chat completion in sync mode
try:
    print("Perform a completion in sync mode")
    prompt = "What is the capital of Germany?"
    print(f"Prompt: {prompt}")
    now = time.time()
    resp = client.chat_completion(prompt)
    print(resp.choices[0].message.content)
    print_diagnostics(resp, int(time.time()-now))
    print()

except Exception as e:
    print(f"An exception occurred: {str(e)}")