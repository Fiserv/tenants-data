# FiservAI Python Package

This demo shows basic usage of the FiservAI python package, which is used to integrate with the Fiserv AI Gateway

## Installation
- Create and activate virtual environment:  
Mac OS command:
`python3.10 -m venv venv; source venv/bin/activate`

Windows OS command:
`py -m venv venv; source venv/bin/activate`
  
- Run the package installation script: `pip3 --trusted-host pypi.org --trusted-host files.pythonhosted.org --trusted-host github.com --trusted-host objects.githubusercontent.com install -r requirements.txt`

## Running the demo
- Run the demo (Mac OS): `python tiny_test.py`
- Run the demo (Windows OS): `py tiny_test.py`
