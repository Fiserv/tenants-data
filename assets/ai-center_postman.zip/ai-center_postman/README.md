# Fiserv Postman Collection

This demo shows how to use the Fiserv AI Center API Keys work with Postman collections.

## Running the Postman Collection
- Create an API Key from AI Center Workspace
- Add the API key to the `ai-gateway-api-lite.postman_environment.json` file, `AppConsumerKey` variable
- Add the API secret to the `ai-gateway-api-lite.postman_environment.json` file, `AppConsumerSecret` variable
- Run the `AI Gateway API Lite.postman_collection.json`
